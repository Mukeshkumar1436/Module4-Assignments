﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace Lab3
{
    public class AssemblyInfo
    {

        [assembly: AssemblyTitle("")]
        [assembly: AssemblyDescription("")]
        [assembly: AssemblyConfiguration("")]
        [assembly: AssemblyCompany("")]
        [assembly: AssemblyProduct("")]
        [assembly: AssemblyCopyright("")]
        [assembly: AssemblyTrademark("")]
        [assembly: AssemblyCulture("")]


        [assembly: AssemblyVersion("1.0.*")]

        [assembly: AssemblyDelaySign(false)]
        [assembly: AssemblyKeyFile("")]
        [assembly: AssemblyKeyName("")]
    }
}



