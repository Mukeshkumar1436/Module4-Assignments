﻿
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Mail;

namespace Email
{
    /// <summary>
    /// Summary description for WebForm1.
    /// </summary>
    public class Email : System.Web.UI.Page
    {
        protected System.Web.UI.WebControls.Label lblFrom;
        protected System.Web.UI.WebControls.Label lblCC;
        protected System.Web.UI.WebControls.TextBox txtFrom;
        protected System.Web.UI.WebControls.TextBox txtCC;
        protected System.Web.UI.WebControls.TextBox txtTo;
        protected System.Web.UI.WebControls.Label lblTo;
        protected System.Web.UI.WebControls.Label lblEmailService;
        protected System.Web.UI.WebControls.TextBox txtBCC;
        protected System.Web.UI.WebControls.Label lblBCC;
        protected System.Web.UI.WebControls.Label lblSubject;
        protected System.Web.UI.WebControls.TextBox txtSubject;
        protected System.Web.UI.WebControls.Label lblMessage;
        protected System.Web.UI.WebControls.TextBox txtMessage;
        protected System.Web.UI.WebControls.Button btnSend;
        protected System.Web.UI.HtmlControls.HtmlInputFile FileBrowse;
        protected System.Web.UI.WebControls.Label lblAttachment;
        protected System.Web.UI.WebControls.RadioButton rbtnAttach;
        protected System.Web.UI.WebControls.RadioButton rbtnDetachment;
        protected System.Web.UI.WebControls.Button btnCancel;
        public string strAttachment;

        private void Page_Load(object sender, System.EventArgs e)
        {
            lblMessage.Text = "";
        }

        #region Web Form Designer generated code
        override protected void OnInit(EventArgs e)
        {
            //
            InitializeComponent();
            base.OnInit(e);
        }

        /// <summary>
        /// </summary>
        private void InitializeComponent()
        {
            this.rbtnDetachment.CheckedChanged += new System.EventHandler(this.rbtnDetachment_CheckedChanged);
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            this.rbtnAttach.CheckedChanged += new System.EventHandler(this.rbtnAttach_CheckedChanged);
            this.Load += new System.EventHandler(this.Page_Load);

        }
        #endregion


        //Method for sending the email
        private void SendMail()
        {

            try
            {

                MailMessage Email = new MailMessage();//Creating the Mail Message object.
                Email.To = txtTo.Text;//Storing the To value in the object reference.
                Email.From = txtFrom.Text;//Storing the From value in the object reference.
                Email.Cc = txtCC.Text;//Storing the CC value in the object reference.
                Email.Bcc = txtBCC.Text;//Storing the BCC value in the object reference.
                Email.Subject = txtSubject.Text;//Storing the Subject value in the object reference.
                Email.Body = txtMessage.Text;//Specifies the email body.
                Email.Priority = MailPriority.High;//Setting priority to the mail as high,low,or normal
                Email.BodyFormat = MailFormat.Text;//Formatting the mail as html or text.
                                                   //Checking whether the attachment is needed or not.
                if (rbtnAttach.Checked)
                {
                    Email.Attachments.Add(new MailAttachment(FileBrowse.Value));//Adding attachment to the mail.
                }
                SmtpMail.SmtpServer.Insert(0, "127.0.0.1");//specifying the real SMTP Mail Server.
                SmtpMail.Send(Email);//Sending the mail.
                Reset();//calling the reset method to erase all the data after sending the mail.
                lblMessage.ForeColor = Color.Navy;
                lblMessage.Text = "*Your email has been sent successfully-Thank You";//User information after submission.
            }
            //Catching Exception 
            catch (Exception exc)
            {
                Reset();
                lblMessage.Text = "Send error:" + exc.ToString();
                lblMessage.ForeColor = Color.Red;

            }
        }
        //Method to reset the text fields.
        private void Reset()
        {
            Control myForm = Page.FindControl("Form1");//Seeking for the controls in the active webform.
            foreach (Control ctl in myForm.Controls)//Iterating each control.
            {
                if (ctl.GetType().ToString().Equals("System.Web.UI.WebControls.TextBox"))//Checking whether it is a text box and clear when it is a textbox.
                    ((TextBox)ctl).Text = "";
            }
        }
        //Event fires for sending the mail.
        private void btnSend_Click(object sender, System.EventArgs e)
        {
            SendMail();
        }
        //Event for cancelling the mail.
        private void btnCancel_Click(object sender, System.EventArgs e)
        {
            Reset();
        }
        //Event for enabling or disabling the File browser.
        private void rbtnAttach_CheckedChanged(object sender, System.EventArgs e)
        {
            FileBrowse.Disabled = false;
        }
        //Event for enabling or disabling the File browser.
        private void rbtnDetachment_CheckedChanged(object sender, System.EventArgs e)
        {
            FileBrowse.Disabled = true;
        }
        
    }
}
