﻿select * from mailusers2
exec sp_help mailusers2

insert into mailusers2 values ('hrishi@gmail.com','Hrishikesh','Hrishi24h','2019-10-24','Swimming');

select * from mailusers2

select * from MailsInBox2