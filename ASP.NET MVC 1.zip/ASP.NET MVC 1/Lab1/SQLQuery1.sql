﻿use Training_23Jan19_Pune;
create table mailusers2(MailUserId varchar(300) Primary Key,
MailUserName varchar(300),
MailUserPwd varchar(300),
AccountCreationDate DateTime,
Hobbies varchar(300));

create table MailsInBox2(
MailTranNo Int Primary Key Identity(1,1),
FromMailUserId varchar(300),
ToMailUserId varchar(300),
subjects varchar(300),
MailText varchar(300),
IsMailNew varchar(300),
MailDateTime DateTime,
);

ALTER TABLE MailsInBox2
ADD CONSTRAINT FK_FromMailUserId
FOREIGN KEY (FromMailUserId) REFERENCES mailusers2(MailUserId);


ALTER TABLE MailsInBox2
ADD CONSTRAINT FK_ToMailUserId
FOREIGN KEY (ToMailUserId) REFERENCES mailusers2(MailUserId);