﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace Lab2._3
{
    public partial class SignIn : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        int records = 0;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSignIn_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("SELECT * FROM mailusers2 WHERE MailUserId = @MailUserId and MailUserPwd=@MailUserPwd", con);
            cmd.Parameters.AddWithValue("@MailUserId", txtUserId.Text);
            cmd.Parameters.AddWithValue("@MailUserPwd", txtPassword.Text);
            con.Open();
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            if (dr.HasRows)
                dt.Load(dr);
            con.Close();
            Response.Write("<script type='text/javascript'>alert('Signed In Successfully')</script>");
            Response.Redirect("Mails.aspx");
        }
    }
}