﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;


namespace Lab2._3
{
    public partial class SignUp : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        SqlCommand cmd = null;
        string strcbl1 = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            cmd = new SqlCommand("Insert into mailusers2(MailUserId,MailUserName,MailUserPwd,AccountCreationDate,Hobbies) values (@MailUserId,@MailUserName,@MailUserPwd,@AccountCreationDate,@Hobbies)", con);
            cmd.Parameters.AddWithValue("@MailUserId", txtUserId.Text);
            cmd.Parameters.AddWithValue("@MailUserName", txtUserName.Text);
            cmd.Parameters.AddWithValue("@MailUserPwd", txtPassword.Text);
            cmd.Parameters.AddWithValue("@AccountCreationDate", Convert.ToDateTime(txtCreationDate.Text));
            for (int i = 0; i < chkHobbies.Items.Count - 1; i++)
            {
                if (chkHobbies.Items[i].Selected == true)
                {
                    strcbl1 = strcbl1 + chkHobbies.Items[i].Value.ToString() + ",";
                }
            }
            cmd.Parameters.AddWithValue("@Hobbies", strcbl1);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Write("<script type='text/javascript'>alert('Signed Up Successfully')</script>");
        }
    }
}