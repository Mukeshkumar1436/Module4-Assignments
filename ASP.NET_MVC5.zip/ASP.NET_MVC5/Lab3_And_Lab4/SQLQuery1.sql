﻿create table Patients(
PatientID int primary key identity(100,1),
PatientName varchar(40),
Gender varchar(10),
Age int ,
Contact varchar(13),
DoctorName varchar(40)
);